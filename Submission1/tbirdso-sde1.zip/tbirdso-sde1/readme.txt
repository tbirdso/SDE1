Pledge:
On my honor I have neither given nor received aid on this
exam
SIGN  Thomas Birdsong
